// ==UserScript==
// @name XYZZY Chat Bleps
// @namespace Violentmonkey Scripts
// @match *://xyzzy.clrtd.com/zy/gameold.jsp*
// @grant none
// ==/UserScript==
function notifyMe(notifcont) {
  if ("Notification" in window) { // if browser supports notifications
    // If it's okay let's create a notification
    //  && (!document.hasFocus() || )
    if (Notification.permission === "granted" && !(document.hasFocus())) {
      var notification = new Notification(notifcont);
    }
    // Otherwise, we need to ask the user for permission
    else if (Notification.permission !== "denied") {
      Notification.requestPermission();
    }
  }
}

var placeholder=cah.log.status_with_game;
cah.log.status_with_game=function(game_id, text, opt_class, opt_allow_html, opt_title) {
  if (game_id !== null) {
    notifyMe(text);
  }
  placeholder(game_id, text, opt_class, opt_allow_html, opt_title);
}

notifyMe('init');

